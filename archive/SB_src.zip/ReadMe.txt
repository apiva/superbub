SUPER BUB CONTEST - Version 1.01.PAL.CW
=======================================

Copyright Alex Herbert 1998



Note:  This source code is for CodeWarrior.


ABOUT THE SOURCE
----------------

OK, so I'm unkind and haven't documented anything.  Sorry, but it would
take me forever.  If you have any comments or questions at all, just
e-mail me - I don't mind how trivial or complex.

Anyhow, you'll need all the data files contained in SuperBub.zip to run
the code, and make sure you've copied them into the same folder as
the SuperBub.mcp project file.  Open up the project file in CW and you
should be able hit the Run/Debug button to compile and execute.



Herbs
aherbert@ndirect.co.uk
